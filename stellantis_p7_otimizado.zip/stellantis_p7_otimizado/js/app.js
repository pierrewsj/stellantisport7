
/**
 * App Stellantis P7 - versão otimizada
 * Mantém as mesmas funções principais:
 * - Login com armazenamento de usuário/registro/turno
 * - Exibição do usuário no menu
 * - Controle de chassi por módulo (industrialização, comissão seguro, qualidade)
 * - Salvamento automático em localStorage
 * - Visualização de tabela
 * - Exportação para Excel por módulo
 */

const P7App = (() => {
  const STORAGE_KEYS = {
    usuario: "p7_usuario",
    registro: "p7_registro",
    turno: "p7_turno",
    moduloData: (mod) => `p7_registros_${mod}`
  };

  function getUser() {
    return {
      usuario: localStorage.getItem(STORAGE_KEYS.usuario) || "",
      registro: localStorage.getItem(STORAGE_KEYS.registro) || "",
      turno: localStorage.getItem(STORAGE_KEYS.turno) || ""
    };
  }

  function setUser({usuario, registro, turno}) {
    if (usuario != null) localStorage.setItem(STORAGE_KEYS.usuario, usuario.trim());
    if (registro != null) localStorage.setItem(STORAGE_KEYS.registro, (registro+"").trim());
    if (turno != null) localStorage.setItem(STORAGE_KEYS.turno, turno.trim());
  }

  function requireUser() {
    const u = getUser();
    if (!u.usuario || !u.registro) {
      window.location.href = "index.html";
      return null;
    }
    return u;
  }

  function showToast(msg, type = "info") {
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      document.body.appendChild(container);
    }
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = msg;
    if (type === "error") {
      toast.style.background = "#ff5252";
    } else if (type === "success") {
      toast.style.background = "#4caf50";
    }
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 400);
    }, 2600);
  }

  /* ===== LOGIN ===== */
  function initLogin() {
    const form = document.getElementById("loginForm");
    const usuarioInput = document.getElementById("usuario");
    const registroInput = document.getElementById("registro");
    const turnoSelect = document.getElementById("turno");

    const u = getUser();
    if (u.usuario) usuarioInput.value = u.usuario;
    if (u.registro) registroInput.value = u.registro;
    if (u.turno) turnoSelect.value = u.turno;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const usuario = usuarioInput.value.trim();
      const registro = registroInput.value.trim();
      const turno = turnoSelect.value.trim();
      if (!usuario || !registro || !turno) {
        showToast("Preencha todas as informações.", "error");
        return;
      }
      setUser({usuario, registro, turno});
      showToast("Login efetuado com sucesso!", "success");
      setTimeout(() => {
        window.location.href = "interface_principal.html";
      }, 400);
    });
  }

  /* ===== MENU ===== */
  function initMenu() {
    const user = requireUser();
    if (!user) return;

    const usuarioExibido = document.getElementById("usuarioExibido");
    if (usuarioExibido) {
      usuarioExibido.textContent = `👤 ${user.usuario} / ${user.registro} - Turno: ${user.turno}`;
    }

    const btnTrocar = document.getElementById("btnTrocarUsuario");
    const btnFinalizar = document.getElementById("btnFinalizarTurno");
    if (btnTrocar) {
      btnTrocar.addEventListener("click", () => {
        if (confirm("Deseja trocar o usuário?")) {
          localStorage.removeItem(STORAGE_KEYS.usuario);
          localStorage.removeItem(STORAGE_KEYS.registro);
          localStorage.removeItem(STORAGE_KEYS.turno);
          window.location.href = "index.html";
        }
      });
    }
    if (btnFinalizar) {
      btnFinalizar.addEventListener("click", async () => {
        const ok = confirm("Deseja finalizar o turno e exportar os dados para Excel?");
        if (!ok) return;
        try {
          await exportAllModulesToExcel();
          showToast("Planilha consolidada gerada com sucesso!", "success");
        } catch (e) {
          console.error(e);
          showToast("Erro ao gerar planilha. Verifique se o navegador permite downloads.", "error");
        }
      });
    }
  }

  /* ===== CONTROLE POR MÓDULO ===== */

  function readModuleData(modKey) {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.moduloData(modKey));
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveModuleData(modKey, arr) {
    localStorage.setItem(STORAGE_KEYS.moduloData(modKey), JSON.stringify(arr));
  }

  function initControlePage() {
    const user = requireUser();
    if (!user) return;

    const body = document.body;
    const modKey = body.dataset.modulo; // "industrializacao" | "comissao_seguro" | "qualidade"
    const modLabel = body.dataset.moduloLabel || "Módulo";
    const setorInput = document.getElementById("setor");
    const turnoInput = document.getElementById("turno");
    const controladorInput = document.getElementById("controladorAcesso");
    const chassiInput = document.getElementById("numeroChassi");
    const observacaoInput = document.getElementById("observacao");
    const tipoMovSelect = document.getElementById("tipoMovimentacao");
    const motivoReInput = document.getElementById("motivoReentrada");
    const infoDiv = document.getElementById("info");
    const icon = document.getElementById("chassiConfirmIcon");
    const tabelaContainer = document.getElementById("tabelaContainer");
    const tabelaBody = document.querySelector("#tabelaRegistros tbody");
    const btnToggleTabela = document.getElementById("btnToggleTabela");
    const btnOutrasInfos = document.getElementById("btnOutrasInfos");
    const botoesInternos = document.getElementById("botoesInternos");
    const btnExportar = document.getElementById("btnExportarExcel");
    const btnLimpar = document.getElementById("btnLimparRegistros");
    const btnSair = document.getElementById("btnSairModulo");

    if (turnoInput) turnoInput.value = user.turno;
    if (controladorInput) controladorInput.value = `${user.usuario} / ${user.registro}`;

    let registros = readModuleData(modKey);
    renderTabela();

    if (infoDiv && registros.length > 0) {
      const last = registros[registros.length - 1];
      infoDiv.innerHTML = `<span class="info-label">Último chassi:&nbsp;</span><span class="info-value">${last.chassi}</span>`;
    }

    if (chassiInput) {
      chassiInput.focus();
      chassiInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          adicionarRegistro();
        }
      });
    }

    function adicionarRegistro() {
      const chassi = (chassiInput.value || "").trim().toUpperCase();
      if (!chassi) {
        showToast("Informe o número de chassi.", "error");
        return;
      }
      if (chassi.length < 5) {
        if (!confirm("O chassi parece muito curto. Deseja registrar mesmo assim?")) {
          return;
        }
      }

      const now = new Date();
      const registro = {
        dataHora: now.toLocaleString("pt-BR"),
        setor: setorInput ? setorInput.value : "",
        turno: user.turno,
        controlador: `${user.usuario} / ${user.registro}`,
        modulo: modLabel,
        chassi,
        tipoMovimentacao: tipoMovSelect ? tipoMovSelect.value : "",
        motivoReentrada: motivoReInput ? motivoReInput.value.trim() : "",
        observacao: observacaoInput ? observacaoInput.value.trim() : ""
      };

      registros.push(registro);
      saveModuleData(modKey, registros);
      renderTabela();
      if (infoDiv) {
        infoDiv.innerHTML = `<span class="info-label">Último chassi:&nbsp;</span><span class="info-value">${chassi}</span>`;
      }
      if (icon) {
        icon.classList.add("visible");
        setTimeout(() => icon.classList.remove("visible"), 600);
      }
      chassiInput.value = "";
      chassiInput.focus();
      if (observacaoInput) observacaoInput.value = "";
      if (motivoReInput) motivoReInput.value = "";
    }

    function renderTabela() {
      if (!tabelaBody) return;
      tabelaBody.innerHTML = "";
      registros.forEach((reg, idx) => {
        const tr = document.createElement("tr");
        const cols = [
          idx + 1,
          reg.dataHora,
          reg.setor,
          reg.turno,
          reg.controlador,
          reg.modulo,
          reg.chassi,
          reg.tipoMovimentacao || "-",
          reg.motivoReentrada || "-",
          reg.observacao || "-"
        ];
        cols.forEach(val => {
          const td = document.createElement("td");
          td.textContent = val;
          tr.appendChild(td);
        });
        tabelaBody.appendChild(tr);
      });
    }

    if (btnToggleTabela && tabelaContainer) {
      btnToggleTabela.addEventListener("click", () => {
        const vis = !tabelaContainer.classList.contains("hidden");
        if (vis) {
          tabelaContainer.classList.add("hidden");
          btnToggleTabela.innerText = "Visualizar tabela";
        } else {
          tabelaContainer.classList.remove("hidden");
          btnToggleTabela.innerText = "Ocultar tabela";
        }
      });
    }

    if (btnOutrasInfos && botoesInternos) {
      btnOutrasInfos.addEventListener("click", () => {
        botoesInternos.classList.toggle("hidden");
      });
    }

    if (btnExportar) {
      btnExportar.addEventListener("click", async () => {
        try {
          if (!registros.length) {
            showToast("Não há registros para exportar.", "error");
            return;
          }
          await exportModuleToExcel(modKey, modLabel, registros);
          showToast("Planilha exportada com sucesso!", "success");
        } catch (e) {
          console.error(e);
          showToast("Erro ao exportar planilha.", "error");
        }
      });
    }

    if (btnLimpar) {
      btnLimpar.addEventListener("click", () => {
        if (!registros.length) {
          showToast("Não há registros para limpar.", "info");
          return;
        }
        const ok = confirm("Deseja excluir TODOS os registros deste módulo?");
        if (!ok) return;
        registros = [];
        saveModuleData(modKey, registros);
        renderTabela();
        if (infoDiv) infoDiv.textContent = "";
      });
    }

    if (btnSair) {
      btnSair.addEventListener("click", () => {
        window.location.href = "interface_principal.html";
      });
    }

    const btnAdicionar = document.getElementById("btnAdicionar");
    if (btnAdicionar) {
      btnAdicionar.addEventListener("click", (e) => {
        e.preventDefault();
        adicionarRegistro();
      });
    }
  }

  /* ===== EXPORTAÇÃO PARA EXCEL ===== */

  async function exportModuleToExcel(modKey, modLabel, registros) {
    if (typeof ExcelJS === "undefined" || typeof saveAs === "undefined") {
      alert("Bibliotecas ExcelJS e FileSaver não foram carregadas.");
      throw new Error("Excel libs missing");
    }
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet(modLabel);

    ws.columns = [
      { header: "ID", key: "id", width: 6 },
      { header: "Data / Hora", key: "dataHora", width: 20 },
      { header: "Setor", key: "setor", width: 18 },
      { header: "Turno", key: "turno", width: 10 },
      { header: "Controlador", key: "controlador", width: 25 },
      { header: "Módulo", key: "modulo", width: 20 },
      { header: "Chassi", key: "chassi", width: 22 },
      { header: "Tipo movimentação", key: "tipoMovimentacao", width: 18 },
      { header: "Motivo reentrada", key: "motivoReentrada", width: 22 },
      { header: "Observação", key: "observacao", width: 30 }
    ];

    registros.forEach((reg, idx) => {
      ws.addRow({
        id: idx + 1,
        ...reg
      });
    });

    const buf = await wb.xlsx.writeBuffer();
    const nomeArquivo = `P7_${modKey}_${new Date().toISOString().slice(0,10)}.xlsx`;
    saveAs(new Blob([buf], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}), nomeArquivo);
  }

  async function exportAllModulesToExcel() {
    if (typeof ExcelJS === "undefined" || typeof saveAs === "undefined") {
      alert("Bibliotecas ExcelJS e FileSaver não foram carregadas.");
      throw new Error("Excel libs missing");
    }

    const wb = new ExcelJS.Workbook();
    const modules = [
      { key: "industrializacao", label: "Industrialização" },
      { key: "comissao_seguro", label: "Comissão Seguro" },
      { key: "qualidade", label: "Qualidade / CI" }
    ];

    let totalRegistros = 0;

    for (const m of modules) {
      const registros = readModuleData(m.key);
      if (!registros.length) continue;
      totalRegistros += registros.length;

      const ws = wb.addWorksheet(m.label);
      ws.columns = [
        { header: "ID", key: "id", width: 6 },
        { header: "Data / Hora", key: "dataHora", width: 20 },
        { header: "Setor", key: "setor", width: 18 },
        { header: "Turno", key: "turno", width: 10 },
        { header: "Controlador", key: "controlador", width: 25 },
        { header: "Módulo", key: "modulo", width: 20 },
        { header: "Chassi", key: "chassi", width: 22 },
        { header: "Tipo movimentação", key: "tipoMovimentacao", width: 18 },
        { header: "Motivo reentrada", key: "motivoReentrada", width: 22 },
        { header: "Observação", key: "observacao", width: 30 }
      ];
      registros.forEach((reg, idx) => {
        ws.addRow({
          id: idx + 1,
          ...reg
        });
      });
    }

    if (!totalRegistros) {
      showToast("Nenhum registro encontrado nos módulos para exportação.", "info");
      return;
    }

    const buf = await wb.xlsx.writeBuffer();
    const hoje = new Date().toISOString().slice(0,10);
    const nomeArquivo = `P7_CONSOLIDADO_${hoje}.xlsx`;
    saveAs(new Blob([buf], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}), nomeArquivo);
  }

  /* ===== INIT GERAL ===== */

  function init() {
    const page = document.body.dataset.page;
    if (page === "login")      initLogin();
    else if (page === "menu")  initMenu();
    else if (page === "controle") initControlePage();
  }

  document.addEventListener("DOMContentLoaded", init);

  // API pública se precisar usar no HTML no futuro
  return {
    exportAllModulesToExcel,
    exportModuleToExcel
  };
})();
